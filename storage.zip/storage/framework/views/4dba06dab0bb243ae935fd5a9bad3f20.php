

<?php $__env->startSection('content'); ?>

<div class="hero-wrap" style="background-image: url('<?php echo e(asset('frontend/images/bg_3.jpg')); ?>');">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text d-flex align-itemd-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          <div class="text">
            <h1 class="mb-4 bread">About Aceh Kuliner</h1>
          </div>
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section ftco-wrap-about ftco-no-pt ftco-no-pb">
    <div class="container overflow-hidden">
      <div class="row gx-5">
        <div class="col-md-4 d-flex">
          <div class="img ftco-animate" style="background-image: url(<?php echo e(asset('frontend/images/about-1.jpg')); ?>);"></div>
        </div>
        <div class="col-md-8 wrap-about pb-md-3 ftco-animate pr-md-5 pb-md-5 pt-md-4">
          <div class="heading-section mx-auto">
            <span class="subheading">About</span>
            <h2 class="mb-4">Aceh Kuliner</h2>
          </div>
          <p>Selamat datang di Aceh Kuliner, sebuah komunitas yang bertekad untuk mengenalkan kelezatan unik dari Aceh kepada dunia. Kami adalah kelompok pecinta kuliner yang terinspirasi oleh kekayaan budaya dan warisan kuliner Aceh yang kaya. Dalam perjalanan kami, kami telah bersatu untuk menyebarkan pesona dan kelezatan kuliner Aceh kepada masyarakat lokal dan pelancong dari berbagai belahan dunia.

Visi kami adalah menjadi pusat informasi terkemuka tentang kuliner Aceh, mempromosikan kekayaan kuliner Aceh kepada masyarakat luas. Kami percaya bahwa melalui makanan, kita dapat membangun jembatan antarbudaya dan memperkuat ikatan sosial. Misi kami adalah mendukung pengusaha kuliner lokal, mempromosikan keragaman kuliner Aceh, dan meningkatkan kesadaran masyarakat tentang warisan kuliner yang berharga ini.

Dengan keaslian, keragaman, dan koneksi komunitas kami, kami berkomitmen untuk menyajikan informasi yang akurat dan pengalaman yang otentik tentang kuliner Aceh. Kami mengundang Anda untuk bergabung dengan kami dalam menjelajahi dunia kuliner Aceh yang kaya dan mendalam. Bersama-sama, mari kita telusuri dan nikmati kelezatan tak terbatas dari Aceh.

.</p>
        </div>
      </div>
    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel10\kuliner\resources\views/frontend/about.blade.php ENDPATH**/ ?>