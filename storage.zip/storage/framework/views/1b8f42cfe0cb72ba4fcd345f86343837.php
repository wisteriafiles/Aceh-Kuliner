

<?php $__env->startSection('content'); ?>
<div class="hero-wrap" style="height:200px;background-image: url('<?php echo e(asset('frontend/images/bg_3.jpg')); ?>');">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text d-flex align-itemd-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section ftco-degree-bg">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10 ftco-animate">
          <h2 class="mb-3"><?php echo e($post->title); ?></h2>
          <nav aria-label="breadcrumb" style="background-color: transparent;">
            <ol style="background-color: transparent;padding:0;" class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('blog')); ?>">Foods</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->title); ?></li>
            </ol>
          </nav>
          <img src="<?php echo e(Storage::url($post->thumbnail)); ?>" alt="" class="img-fluid">
        <?php echo $post->description; ?> 
        </div>

      </div>
    </div>
  </section> <!-- .section -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel10\kuliner\resources\views/frontend/blog/show.blade.php ENDPATH**/ ?>