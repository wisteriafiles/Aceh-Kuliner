@extends('frontend.layout ')

@section('content')
	<div class="hero">
		<section class="home-slider owl-carousel">
			@foreach ($sliders as $slider )
			<div class="slider-item" style="background-image:url({{Storage::url($slider->thumbnail)}} );">
				<div class="overlay"></div>
				<div class="container">
					<div class="row justify-content-center no-gutters slider-text align-items-center justify-content-end">
						<div class="col-md-10 ftco-animate">
							<div class="text text-center">
								<h2>Welcome To Aceh Kuliner</h2>
								<h1 class="mb-3">{{ $slider->tittle }}.</h1>
							</div>
						</div>
					</div>
				</div>
			</div>
			@endforeach
		</section>
	</div>

	<section class="ftco-section ftco-wrap-about ftco-no-pt ftco-no-pb">
		<div class="container">
			<div class="row no-gutters">
				<div class="col-md-7 order-md-last d-flex">
					<div class="img img-1 mr-md-2 ftco-animate" style="background-image: url(images/about-1.jpg);">
					</div>
					<div class="img img-2 ml-md-2 ftco-animate" style="background-image: url(images/about-2.jpg);">
					</div>
				</div>
				<div class="col-md-5 wrap-about pb-md-3 ftco-animate pr-md-5 pb-md-5 pt-md-4">
					<div class="heading-section mb-4 my-5 my-md-0">
						<h2 class="mb-4">Aceh Kuliner</h2>
					</div>
					<p>Disini kami menyediakan beberapa informasi tentang kuliner yang dapat dinikmati di Aceh serta restoran dan tempatnya, sehingga memudahkan anda dalam mencari dan mengunjunginya. Dengan ada nya website ini, kami mengharapkan anda dapat dengan mudah menikmati ragam cita rasa yang dihidangkan oleh makanan khas Aceh dengan mudah.</p>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center mb-5 pb-3">
				<div class="col-md-7 heading-section text-center ftco-animate">
					<span class="subheading">Read Foods</span>
					<h2>Recent Foods</h2>
				</div>
			</div>
			<div class="row d-flex">
				@foreach ($posts as $post )
				<div class="col-md-4 d-flex ftco-animate">
					<div class="blog-entry align-self-stretch">
						<a href="{{ route('blog.slug', $post->slug) }}" class="block-20 rounded"
							style="background-image: url('{{ Storage::url($post->thumbnail) }}');">
						</a>
						<div class="text mt-3 text-center">
							<h3 class="heading"><a href="{{ route('blog.slug', $post->slug) }}">{{ $post->tittle }}</a></h3>
						</div>
					</div>
				</div>
				@endforeach
			</div>
		</div>
	</section>
@endsection