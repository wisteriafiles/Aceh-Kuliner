@extends('frontend.layout')

@section('content')
<div class="hero-wrap" style="height:200px;background-image: url('{{ asset('frontend/images/bg_3.jpg') }}');">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text d-flex align-itemd-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section ftco-degree-bg">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10 ftco-animate">
          <h2 class="mb-3">{{ $post->title }}</h2>
          <nav aria-label="breadcrumb" style="background-color: transparent;">
            <ol style="background-color: transparent;padding:0;" class="breadcrumb">
              <li class="breadcrumb-item"><a href="{{ route('blog') }}">Foods</a></li>
              <li class="breadcrumb-item active" aria-current="page">{{ $post->title }}</li>
            </ol>
          </nav>
          <img src="{{ Storage::url($post->thumbnail) }}" alt="" class="img-fluid">
        {!! $post->description !!} 
        </div>

      </div>
    </div>
  </section> <!-- .section -->
  @endsection