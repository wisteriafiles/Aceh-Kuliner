@extends('frontend.layout')

@section('content')
<div class="hero-wrap" style="background-image: url('{{ asset('frontend/images/bg_3.jpg') }}');">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text d-flex align-itemd-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          <div class="text">
            <h1 class="mb-4 bread">Our Foods</h1>
          </div>
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section">
    <div class="container">
      <div class="row d-flex">
        @foreach ($posts as $post )
        <div class="col-md-4 d-flex ftco-animate">
          <div class="blog-entry align-self-stretch">
            <a href="{{ route('blog.slug', $post->slug) }}" class="block-20 rounded" style="background-image: url({{ Storage::url($post->thumbnail) }});">
            </a>
            <div class="text mt-3">
              <h3 class="heading"><a href="{{ route('blog.slug', $post->slug) }}">"{{ $post->title }}"</a>
              </h3>
            </div>
          </div>
        </div>
        @endforeach
      </div>
      <div class="row justify-content-center mt-5">
        <div class="text-center">
          <div class="block-27">
            {{ $posts->links()}}
          </div>
        </div>
      </div>
    </div>
  </section>
  @endsection