<?php

namespace App\Http\Controllers\frontend;

use App\Models\Post;
use App\Models\Slider;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $sliders = Slider::get();
        $posts = Post::get();

        return view('frontend.home', compact('sliders', 'posts'));
    }
}
