<?php

namespace App\Http\Controllers\frontend;

use App\Models\Post;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index()
    {
        $posts = Post::paginate(2);

        return view('frontend.blog.index', compact('posts'));
    }

    public function show(Post $post)
    {
        return view('frontend.blog.show', compact('post'));
    }
}
